package com.tb.mvvm_library.uiActivity

/**
*@作者：tb
*@时间：2019/7/10
*@描述：选择图库的基类
*/
class TbSelectPictureActivity :TbBaseActivity(){

}