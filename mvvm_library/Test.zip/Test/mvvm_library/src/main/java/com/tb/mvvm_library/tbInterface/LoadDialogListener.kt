package com.tb.mvvm_library.tbInterface

/**
 *@作者：tb
 *@时间：2019/6/28
 *@描述：加载框显示与消失的监听
 */
interface LoadDialogListener {
    fun showLoadDialog()
    fun  dismissLoadDialog()

}