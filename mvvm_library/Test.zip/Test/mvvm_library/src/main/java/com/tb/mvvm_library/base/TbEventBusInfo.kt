package com.tb.mvvm_library.base

import android.os.Bundle

/**
*@作者：tb
*@时间：2019/7/4
*@描述：
*/
class TbEventBusInfo(var bundle: Bundle)