package com.tb.test.activity

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.tb.mvvm_library.uiFragment.TbBaseTitleFragment
import com.tb.test.R

class TestFragment : TbBaseTitleFragment() {
    override fun loadData() {

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootLayoutId = R.layout.header
        return super.onCreateView(inflater, container, savedInstanceState)
    }


    override fun initView() {
        super.initView()
        initToolBar()
        setTitleCenter("ssss")
    }
}