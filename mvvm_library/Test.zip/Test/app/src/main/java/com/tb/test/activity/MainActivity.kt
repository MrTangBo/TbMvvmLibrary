package com.tb.test.activity


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.tb.mvvm_library.tbExtend.*
import com.tb.mvvm_library.tbInterface.LoadDialogListener
import com.tb.mvvm_library.tbZxingUtil.android.TbCaptureActivity
import com.tb.mvvm_library.tbZxingUtil.common.Constant.CODED_CONTENT
import com.tb.mvvm_library.uiActivity.TbBaseTitleActivity
import com.tb.test.R
import com.tb.test.TestModle
import com.tb.test.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : TbBaseTitleActivity(), LoadDialogListener {

    var model: TestModle? = null

    var bing: ActivityMainBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        tbStatusBarInit(statusColorId = R.color.tb_green)
        rootLayoutId = R.layout.activity_main
        super.onCreate(savedInstanceState)


//        initToolBar("")
//
//        initMenu(
//            arrayListOf("打印", R.drawable.tb_back_white)
//        )
//
//        setTitleCenter("asdadsad")
//
//
//        requestPermission(
//            arrayListOf(
//                PermissionItem(Manifest.permission.CAMERA, "相机", R.drawable.permission_ic_camera),
//                PermissionItem(Manifest.permission.WRITE_EXTERNAL_STORAGE, "存储", R.drawable.permission_ic_camera))
//            ,colorId = R.color.white,styleId = R.style.PermissionDefaultBlueStyle
//        ,permissionFault = {
//
//            },permissionSuccess = {
//
//            }
//        )
//        val listData = arrayListOf<String>()
//        listData.add("ssss")
//        listData.add("ssss")
//        listData.add("ssss")
//        listData.add("ssss")
//        listData.add("ssss")
//        val adapter = TestAdapter(list, listData, R.layout.item)
//
//        adapter.itemClick = {
//            tbShowToast("$it")
//        }
//
//        list.layoutManager = LinearLayoutManager(mContext, RecyclerView.VERTICAL, false)
//        list.adapter = adapter
//
//        menuClick = {
//            tbShowToast("${it}")
//        }

//        tx.setOnClickListener {
        //            val pop = TbPopupWindow(
//                this,
//                R.layout.pop_test,
//                windowWith = ViewGroup.LayoutParams.MATCH_PARENT
//
//
//            )
//            val bi: PopTestBinding = pop.popBaseBind as PopTestBinding
//            pop.showAtLocationBottom(it,0)

//        }


        val images = arrayListOf(
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1566900716053&di=3ec42f383a336f24ca997e710951ea17&imgtype=0&src=http%3A%2F%2Fimg3.cache.netease.com%2Fgame%2F2013%2F11%2F26%2F20131126143638f53f4.png",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1565257547529&di=6e33501cae7f535fc3d24bdbc60c708f&imgtype=0&src=http%3A%2F%2Fb.zol-img.com.cn%2Fsoft%2F6%2F571%2FcepyVKtIjudo6.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1565257547529&di=82d253733a8ff88a87b8151478c84b61&imgtype=0&src=http%3A%2F%2Fpic.rmb.bdstatic.com%2Ff54083119edfb83c4cfe9ce2eeebc076.jpeg"

        )

        mBanner.initBanner(images, itemClick = { position ->
            tbShowToast("$position")
        })

        image.showImage(images[0],scaleType = ImageView.ScaleType.CENTER_INSIDE)
        image.tbImageLongPress(this,readQRCode = {
            tbShowToast(it)
        })

//        tx.setOnClickListener
        tx.setOnClickListener {
            //            val fragmentDialog = TbSelectPictureDialog()
//            fragmentDialog.apply {
//                pictureClick={
//                    tbShowToast("ss")
//                }
//                takePhotoClick={
//                    tbShowToast("333")
//                }
//                show(supportFragmentManager, "myAlert")
//            }


            //                                    EventBus.getDefault().post(TbEventBusInfo(Bundle()))
//            PictureSelector.create(this@MainActivity)
//                .openGallery(PictureMimeType.ofImage())
//                .theme(R.style.tb1)
//                .imageFormat(PictureMimeType.PNG)
//                .circleDimmedLayer(true)
//                .cropWH(1, 1)
//                .enableCrop(true)
//                .forResult(PictureConfig.CHOOSE_REQUEST)
//            images.clear()
//            images.add("https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1565247465&di=6e39ae6182849bf4fc1dc5d4ef2867ab&src=http://pic.rmb.bdstatic.com/cd2476300bbad8dfcfff1d277b79401a.jpeg")
//            mBanner.notifyDataSetChanged()

            tbStartActivity(
                MainActivity2::class.java
            )

//            tbStartActivity(TbCaptureActivity::class.java, requestCode = 300)

        }

//            listData.add("66666")
//            listData.add("66666")
//            listData.add("66666")
//
//            adapter.notifyDataSetChanged()


//            val maker = TestPrintDataMaker(this, "ss", 300, 255)
//            val executor = PrintExecutor(device, PrinterWriter80mm.TYPE_80)
//            executor.setOnPrintResultListener {
//
//            }
//
//            executor.setDevice(device)
//            executor.doPrinterRequestAsync(maker)

//            val mFOne = TestFragment()
//            val fm = supportFragmentManager
//            val tx = fm.beginTransaction()
//            tx.add(R.id.fragment_content, mFOne, "ONE")
//            tx.commitAllowingStateLoss()

//        }

    }

    override fun addModel() {
        super.addModel()
        model = ViewModelProviders.of(this).get(TestModle::class.java)
        modelList.add(model!!)
    }

    override fun initModel() {
        super.initModel()
        model?.liveData?.observe(this, Observer {
            val list: ArrayList<*> = it as ArrayList<*>
            bing?.cotent = (list[0] as TestInfo)
            tbShowToast("${list[1]}")
        })
        loadingDialog?.show()
        model?.getData()
    }

    override fun initView() {
        super.initView()
        bing = baseActivityBing as ActivityMainBinding
        bing?.url = "http://img1.imgtn.bdimg.com/it/u=4026165941,206009312&fm=26&gp=0.jpg"
        bing?.scaleType = ImageView.ScaleType.CENTER_INSIDE
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // 扫描二维码/条码回传
        if (requestCode == 300 && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                val content = data.getStringExtra(CODED_CONTENT)
                tbShowToast(content!!)
            }
        }
    }
}



